extern "C"{
    #include <stdint.h>
}
#include "Hook.h"

// Hook is just a glorified FPointer

Hook::Hook(){}
